/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lifestyletracker;

/**
 *
 * @author angeliparsaso
 */
import java.util.ArrayList;
import java.util.List;
 
public class LifestyleTracker {

    private ArrayList<Food> foodList = new ArrayList<Food>();
    private ArrayList<Activity> activityList = new ArrayList<Activity>();

    public LifestyleTracker() {
    }

    public String addFood(String f, double c) {
        return "";
    }

    public String addActivity(String activityName, double actCalorieValue) {
        return "";
    }

    public String eat(String foodName, double foodServings) {
        return "";
    }

    public String perform(String activityName, double activityhours) {
        return "";
    }

    public String report() {
        return "";
    }

}
