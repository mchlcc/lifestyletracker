/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lifestyletracker;

import java.util.Scanner;

/**
 *
 * @author sbc-student
 */
public class TrackerConsole {

    public static void main(String[] args) {
        LifestyleTracker tracker = new LifestyleTracker();
        Scanner scanner = new Scanner(System.in);
        String name;
        
        if (args.length == 0) {
            System.out.print("Enter your name: ");
            name = scanner.nextLine();
        } else {
            name = args[0];
        }

        System.out.println("Welcome " + name + "!");
        System.out.println("From the commands Food, Activity, Eat, Perform, Report (eg. Food pizza 100)");
         System.out.println("Food, FoodName, calories");
         System.out.println("Activity, FoodName, calories");
         System.out.println("Eat, FoodName, calories");
         System.out.println("Perform, FoodName, calories");
        
        while (true) {
            String input = scanner.nextLine();
            String[] parts = input.split(" ");
            String command = parts[0];
            
            switch (command) {
                case "Food" -> {                    
                    tracker.addFood(parts[1], Double.parseDouble(parts[2]));
                    System.out.println("Food Added!");
                }
                case "Activity" -> {
                    tracker.addActivity(parts[1], Double.parseDouble(parts[2]));
                     System.out.println("Activity Added!");
                }
                case "Eat" -> {
                    tracker.eat(parts[1], Double.parseDouble(parts[2]));
                     System.out.println("You Ate " + parts[2] + " Servings of " + parts[1]);
                }
                case "Perform" -> {
                    tracker.perform(parts[1], Double.parseDouble(parts[2]));
                     System.out.println("Performance Added!");
                }
                case "Report" -> {
                    System.out.println(tracker.report());
                }
                default -> System.out.println("Invalid command");
            }
        }

    }

}